package com.example.individualassignment;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;
import java.util.ArrayList;
import java.util.Collections;

public class CountingActivity extends AppCompatActivity {
    LinearLayout layoutObjects;
    TextView tvQuestion;
    Button btnOpt1, btnOpt2, btnOpt3;
    Random rand = new Random();
    int correctAnswer;
    int maxNumber = 10; // default easy

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counting);

        layoutObjects = findViewById(R.id.layoutObjects);
        tvQuestion = findViewById(R.id.tvQuestionCounting);
        btnOpt1 = findViewById(R.id.btnOption1);
        btnOpt2 = findViewById(R.id.btnOption2);
        btnOpt3 = findViewById(R.id.btnOption3);

        String difficulty = getIntent().getStringExtra("difficulty");
        if ("hard".equals(difficulty)) maxNumber = 99;

        generateQuestion();

        View.OnClickListener optClick = v -> {
            Button b = (Button) v;
            int val = Integer.parseInt(b.getText().toString());
            if (val == correctAnswer) {
                Toast.makeText(this, "Correct! 🎉", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Try again 😊", Toast.LENGTH_SHORT).show();
            }
            generateQuestion();
        };

        btnOpt1.setOnClickListener(optClick);
        btnOpt2.setOnClickListener(optClick);
        btnOpt3.setOnClickListener(optClick);
    }

    private void generateQuestion() {
        layoutObjects.removeAllViews();
        // pick a random count between 0 and maxNumber (for easy <=10)
        correctAnswer = rand.nextInt(maxNumber + 1);

        tvQuestion.setText("How many apples do you see?");

        // show objects as emoji textviews in rows
        int perRow = 6;
        LinearLayout row = null;
        for (int i = 0; i < correctAnswer; i++) {
            if (i % perRow == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                layoutObjects.addView(row);
            }
            TextView t = new TextView(this);
            t.setText("🍎");
            t.setTextSize(36f);
            t.setPadding(8, 8, 8, 8);
            row.addView(t);
        }

        // If 0, show "None" text big
        if (correctAnswer == 0) {
            TextView none = new TextView(this);
            none.setText("None");
            none.setTextSize(28f);
            layoutObjects.addView(none);
        }

        // prepare 3 options
        ArrayList<Integer> opts = new ArrayList<>();
        opts.add(correctAnswer);
        while (opts.size() < 3) {
            int candidate = Math.max(0, correctAnswer + rand.nextInt(5) - 2);
            candidate = Math.min(maxNumber, candidate + rand.nextInt(5) - 2);
            if (!opts.contains(candidate)) opts.add(candidate);
            // random fallback
            if (opts.size() < 3 && rand.nextBoolean()) opts.add(rand.nextInt(maxNumber + 1));
        }
        Collections.shuffle(opts);
        btnOpt1.setText(String.valueOf(opts.get(0)));
        btnOpt2.setText(String.valueOf(opts.get(1)));
        btnOpt3.setText(String.valueOf(opts.get(2)));
    }
}