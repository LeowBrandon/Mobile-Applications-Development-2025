package com.example.individualassignment;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;
import java.util.ArrayList;
import java.util.Collections;

public class MissingNumberActivity extends AppCompatActivity {
    TextView tvSequence;
    Button b1, b2, b3;
    Random rand = new Random();
    int correct;
    int maxNumber = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_missing_number);

        tvSequence = findViewById(R.id.tvSequence);
        b1 = findViewById(R.id.btnM1);
        b2 = findViewById(R.id.btnM2);
        b3 = findViewById(R.id.btnM3);

        String difficulty = getIntent().getStringExtra("difficulty");
        if ("hard".equals(difficulty)) maxNumber = 99;

        generateSequence();

        View.OnClickListener click = v -> {
            Button b = (Button) v;
            int val = Integer.parseInt(b.getText().toString());
            if (val == correct) {
                Toast.makeText(this, "Correct! 🎉", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Try again 👍", Toast.LENGTH_SHORT).show();
            }
            generateSequence();
        };

        b1.setOnClickListener(click);
        b2.setOnClickListener(click);
        b3.setOnClickListener(click);
    }

    private void generateSequence() {
        // create simple arithmetic sequence or pattern (step 1 or 2 commonly)
        int start = rand.nextInt(Math.max(1, maxNumber - 4));
        int step = (rand.nextBoolean() ? 1 : 2);
        int length = 5;
        ArrayList<Integer> seq = new ArrayList<>();
        for (int i = 0; i < length; i++) seq.add(start + i * step);

        int missingIndex = rand.nextInt(length);
        correct = seq.get(missingIndex);

        // build display string with ? at missing index
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < seq.size(); i++) {
            if (i == missingIndex) sb.append(" ? ");
            else sb.append(" ").append(seq.get(i)).append(" ");
            if (i < seq.size() - 1) sb.append(", ");
        }
        tvSequence.setText("Find the missing number:\n" + sb.toString());

        // options generation
        ArrayList<Integer> opts = new ArrayList<>();
        opts.add(correct);
        while (opts.size() < 3) {
            int candidate = correct + (rand.nextInt(5) - 2);
            if (candidate < 0) candidate = Math.abs(candidate);
            if (!opts.contains(candidate)) opts.add(candidate);
            if (opts.size() < 3 && rand.nextBoolean()) opts.add(rand.nextInt(maxNumber + 1));
        }
        Collections.shuffle(opts);
        b1.setText(String.valueOf(opts.get(0)));
        b2.setText(String.valueOf(opts.get(1)));
        b3.setText(String.valueOf(opts.get(2)));
    }
}