package com.example.individualassignment;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;
import java.util.ArrayList;
import java.util.Collections;
import java.text.NumberFormat;
import java.util.Locale;

public class NumberRecognitionActivity extends AppCompatActivity {
    TextView tvNumber;
    Button btn1, btn2, btn3;
    Random rand = new Random();
    int correctNumber;
    int maxNumber = 10;

    // english words for numbers 0-99 (we will programmatically convert tens+units)
    private static final String[] ONES = {
            "zero","one","two","three","four","five","six","seven","eight","nine","ten",
            "eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen"
    };
    private static final String[] TENS = {
            "","","twenty","thirty","forty","fifty","sixty","seventy","eighty","ninety"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_number_recognition);

        tvNumber = findViewById(R.id.tvNumber);
        btn1 = findViewById(R.id.btnNR1);
        btn2 = findViewById(R.id.btnNR2);
        btn3 = findViewById(R.id.btnNR3);

        String difficulty = getIntent().getStringExtra("difficulty");
        if ("hard".equals(difficulty)) maxNumber = 99;

        generateQuestion();

        View.OnClickListener click = v -> {
            Button b = (Button) v;
            String picked = b.getText().toString().trim();
            String correctWord = numberToWords(correctNumber);
            if (picked.equalsIgnoreCase(correctWord)) {
                Toast.makeText(this, "Correct! 🌟", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Try again 🙂", Toast.LENGTH_SHORT).show();
            }
            generateQuestion();
        };

        btn1.setOnClickListener(click);
        btn2.setOnClickListener(click);
        btn3.setOnClickListener(click);
    }

    private void generateQuestion() {
        correctNumber = rand.nextInt(maxNumber + 1);
        tvNumber.setText(String.valueOf(correctNumber));

        ArrayList<String> options = new ArrayList<>();
        options.add(numberToWords(correctNumber));
        while (options.size() < 3) {
            int other = rand.nextInt(maxNumber + 1);
            String w = numberToWords(other);
            if (!options.contains(w)) options.add(w);
        }
        Collections.shuffle(options);
        btn1.setText(options.get(0));
        btn2.setText(options.get(1));
        btn3.setText(options.get(2));
    }

    private String numberToWords(int n) {
        if (n < 20) return ONES[n];
        if (n < 100) {
            int tens = n / 10;
            int ones = n % 10;
            if (ones == 0) return TENS[tens];
            return TENS[tens] + "-" + ONES[ones];
        }
        return String.valueOf(n);
    }
}
