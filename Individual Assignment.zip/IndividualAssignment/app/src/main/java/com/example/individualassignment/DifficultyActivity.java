package com.example.individualassignment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;

public class DifficultyActivity extends AppCompatActivity {
    Button btnEasy, btnHard;
    String topic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_difficulty);

        topic = getIntent().getStringExtra("topic");
        btnEasy = findViewById(R.id.btnEasy);
        btnHard = findViewById(R.id.btnHard);

        btnEasy.setOnClickListener(v -> openTopic("easy"));
        btnHard.setOnClickListener(v -> openTopic("hard"));
    }

    private void openTopic(String difficulty) {
        Intent i = null;
        switch (topic) {
            case "counting":
                i = new Intent(this, CountingActivity.class);
                break;
            case "number_recognition":
                i = new Intent(this, NumberRecognitionActivity.class);
                break;
            case "missing_number":
                i = new Intent(this, MissingNumberActivity.class);
                break;
        }
        if (i != null) {
            i.putExtra("difficulty", difficulty);
            startActivity(i);
            finish();
        }
    }
}