package com.example.individualassignment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnCounting, btnNumberRecognition, btnMissingNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnCounting = findViewById(R.id.btnCounting);
        btnNumberRecognition = findViewById(R.id.btnNumberRecognition);
        btnMissingNumber = findViewById(R.id.btnMissingNumber);

        View.OnClickListener goToDifficulty = v -> {
            Intent i = new Intent(MainActivity.this, DifficultyActivity.class);
            if (v.getId() == R.id.btnCounting) i.putExtra("topic", "counting");
            else if (v.getId() == R.id.btnNumberRecognition) i.putExtra("topic", "number_recognition");
            else if (v.getId() == R.id.btnMissingNumber) i.putExtra("topic", "missing_number");
            startActivity(i);
        };

        btnCounting.setOnClickListener(goToDifficulty);
        btnNumberRecognition.setOnClickListener(goToDifficulty);
        btnMissingNumber.setOnClickListener(goToDifficulty);
    }
}